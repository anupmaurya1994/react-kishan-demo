## Packages
date-fns | Formatting dates for the patient table
framer-motion | Smooth animations for page transitions and interactions

## Notes
Authentication uses /api/user to check session
Dark mode is the default and only theme
