import { 
  ArrowUpDown, 
  Columns, 
  Download, 
  Edit2, 
  Filter, 
  Search, 
  Layout as TableRowIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";

const claimsData = [
  { id: "CLM-20250000425", sampleId: "SMP-500025", patient: "Dorothy Rivera", date: "12/19/2025", test: "Basic Metabolic Panel", cpt: "99232", billed: "$205.00", paid: "$155.00", insurance: "Kaiser Permanente", status: "Pending" },
  { id: "CLM-20250000424", sampleId: "SMP-500024", patient: "Brian Hall", date: "12/20/2025", test: "Genetic Screen Panel", cpt: "99231", billed: "$204.00", paid: "$154.00", insurance: "Humana", status: "Partially Paid" },
  { id: "CLM-20250000423", sampleId: "SMP-500023", patient: "Amanda Baker", date: "12/21/2025", test: "Vitamin D Test", cpt: "99285", billed: "$203.00", paid: "-", insurance: "United Healthcare", status: "Approved" },
  { id: "CLM-20250000422", sampleId: "SMP-500022", patient: "Kevin Nelson", date: "12/22/2025", test: "Kidney Function Panel", cpt: "99284", billed: "$202.00", paid: "-", insurance: "Cigna", status: "Paid" },
  { id: "CLM-20250000421", sampleId: "SMP-500021", patient: "Carol Adams", date: "12/23/2025", test: "Liver Function Test", cpt: "99283", billed: "$201.00", paid: "$151.00", insurance: "Blue Cross Blue Shield", status: "Paid" },
  { id: "CLM-20250000420", sampleId: "SMP-500020", patient: "Kenneth Green", date: "12/24/2025", test: "Basic Metabolic Panel", cpt: "99282", billed: "$200.00", paid: "$150.00", insurance: "Aetna", status: "In Review" },
  { id: "CLM-20250000419", sampleId: "SMP-500019", patient: "Deborah Roberts", date: "12/25/2025", test: "Genetic Screen Panel", cpt: "99281", billed: "$199.00", paid: "-", insurance: "Medicare", status: "Submitted" },
];

export default function ClaimsStatus() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight text-white">Claims Status</h1>

      {/* Toolbar */}
      <div className="flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search all columns..." 
            className="bg-[#151b2b] border-white/5 h-10 pl-10 text-sm focus-visible:ring-blue-500/20 placeholder:text-muted-foreground/50"
          />
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="bg-[#151b2b] border-white/10 text-muted-foreground hover:text-white h-9 gap-2">
            <Filter className="w-4 h-4" />
            Filters
          </Button>
          <Button variant="outline" className="bg-[#151b2b] border-white/10 text-muted-foreground hover:text-white h-9 gap-2">
            <ArrowUpDown className="w-4 h-4" />
            Sort
          </Button>
          <Button variant="outline" className="bg-[#151b2b] border-white/10 text-muted-foreground hover:text-white h-9 gap-2">
            <Columns className="w-4 h-4" />
            Columns
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-xl border border-white/10 bg-[#0b1121] overflow-hidden">
        <Table>
          <TableHeader className="bg-[#151b2b]/50 border-b border-white/10">
            <TableRow className="border-white/5 hover:bg-transparent">
              <TableHead className="w-12 px-4 py-4"><Checkbox className="border-white/20" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">Claim # <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">Sample ID <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">Patient <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">Date of Service <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">Test <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">CPT/HCPCS <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">Billed <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">Paid <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">Insurance <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-muted-foreground font-semibold text-[10px] uppercase px-4 whitespace-nowrap">Status <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-50" /></TableHead>
              <TableHead className="text-right text-muted-foreground font-semibold text-[10px] uppercase px-4">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {claimsData.map((claim, i) => (
              <TableRow key={i} className="border-white/5 hover:bg-white/5 transition-colors">
                <TableCell className="px-4 py-4"><Checkbox className="border-white/20" /></TableCell>
                <TableCell className="font-mono text-[11px] px-4 text-white/90">{claim.id}</TableCell>
                <TableCell className="font-mono text-[11px] px-4 text-muted-foreground">{claim.sampleId}</TableCell>
                <TableCell className="font-medium text-[12px] px-4 text-white">{claim.patient}</TableCell>
                <TableCell className="text-muted-foreground text-[11px] px-4">{claim.date}</TableCell>
                <TableCell className="text-white/80 text-[11px] px-4">{claim.test}</TableCell>
                <TableCell className="text-muted-foreground text-[11px] px-4">{claim.cpt}</TableCell>
                <TableCell className="text-white/90 text-[11px] px-4 font-medium">{claim.billed}</TableCell>
                <TableCell className="text-white/90 text-[11px] px-4 font-medium">{claim.paid}</TableCell>
                <TableCell className="text-muted-foreground text-[11px] px-4">{claim.insurance}</TableCell>
                <TableCell className="px-4">
                  <Badge variant="outline" className={`
                    ${claim.status === 'Paid' ? 'bg-green-500/20 text-green-400 border-green-500/30' : 
                      claim.status === 'Approved' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                      claim.status === 'Partially Paid' ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' :
                      claim.status === 'Pending' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                      claim.status === 'In Review' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                      'bg-white/5 text-muted-foreground border-white/10'} 
                    font-semibold px-2 py-0.5 rounded-full text-[10px] whitespace-nowrap
                  `}>
                    {claim.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right px-4">
                  <Button size="icon" variant="ghost" className="w-8 h-8 text-muted-foreground/50 hover:text-white">
                    <Edit2 className="w-4 h-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
