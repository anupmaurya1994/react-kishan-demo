import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter, SidebarProvider } from "@/components/ui/sidebar";
import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  UserCircle, 
  CreditCard, 
  UserPlus, 
  Dna, 
  Pill, 
  Beaker, 
  Terminal, 
  Settings, 
  ShieldCheck, 
  Compass,
  Search,
  Moon,
  LogOut,
  Plus,
  ArrowUpRight,
  Filter,
  ArrowUpDown,
  Columns,
  ShieldAlert,
  Edit2,
  Trash2,
  Eye,
  Bell,
  ChevronDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Patient } from "@shared/schema";
import { Checkbox } from "@/components/ui/checkbox";
import { SiReactos } from "react-icons/si";
import { useLocation } from "wouter";
import DashboardContent from "@/pages/DashboardContent";
import Patients from "@/pages/Patients";
import ClaimsStatus from "@/pages/ClaimsStatus";
import UserList from "@/pages/UserList";

const mainMenuItems = [
  { title: "Dashboard", icon: LayoutDashboard, shortcut: "Alt+1" },
  { title: "Patients", icon: Users, shortcut: "Alt+2" },
  { title: "Claims Status", icon: FileText, shortcut: "Alt+3" },
];

const adminMenuItems = [
  { title: "Accounts", icon: CreditCard },
  { title: "Users", icon: UserPlus, path: "/users" },
  { title: "ICD-10 Codes", icon: Dna },
  { title: "Medications", icon: Pill },
  { title: "Laboratories", icon: Beaker },
  { title: "Developer Portal", icon: Terminal },
  { title: "Preferences", icon: Settings },
  { title: "Security", icon: ShieldCheck },
];

export default function Dashboard() {
  const { logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();
  
  const renderContent = () => {
    if (location === "/dashboard") return <DashboardContent />;
    if (location === "/patients") return <Patients />;
    if (location === "/claims") return <ClaimsStatus />;
    if (location === "/users") return <UserList />;
    return <DashboardContent />;
  };

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-background": "222 47% 11%",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full bg-[#0b1121] text-white overflow-hidden font-sans">
        {/* Sidebar */}
        <Sidebar className="border-r border-white/5 bg-[#0b1121]">
          <SidebarHeader className="p-4 flex items-center justify-between border-b border-white/5 h-14">
            <div className="flex items-center gap-2">
               <Search className="w-4 h-4 text-muted-foreground" />
               <span className="text-sm text-muted-foreground">Search...</span>
            </div>
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          </SidebarHeader>
          
          <SidebarContent className="px-2 py-4 space-y-4">
            <SidebarGroup>
              <SidebarGroupLabel className="text-[10px] uppercase tracking-wider text-muted-foreground/60 font-bold px-2 mb-2 flex items-center justify-between w-full">
                MAIN
                <ChevronDown className="w-3 h-3" />
              </SidebarGroupLabel>
              <SidebarMenu>
                {mainMenuItems.map((item) => {
                  const path = item.title === "Dashboard" ? "/dashboard" : item.title === "Patients" ? "/patients" : item.title === "Claims Status" ? "/claims" : "#";
                  const active = location === path;
                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        onClick={() => setLocation(path)}
                        isActive={active}
                        className={`h-9 px-2 rounded-md transition-colors ${active ? 'bg-[#1e293b] text-blue-400' : 'hover:bg-white/5 text-muted-foreground'}`}
                      >
                        <item.icon className={`w-4 h-4 mr-2 ${active ? 'text-blue-400' : 'text-muted-foreground'}`} />
                        <span className="flex-1 text-sm font-medium">{item.title}</span>
                        <span className="text-[9px] bg-white/5 px-1 rounded opacity-40">{item.shortcut}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel className="text-[10px] uppercase tracking-wider text-muted-foreground/60 font-bold px-2 mb-2 flex items-center justify-between w-full">
                ADMIN
                <ChevronDown className="w-3 h-3" />
              </SidebarGroupLabel>
              <SidebarMenu>
                {adminMenuItems.map((item) => {
                  const path = item.path || "#";
                  const active = location === path;
                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        onClick={() => path !== "#" && setLocation(path)}
                        isActive={active}
                        className={`h-9 px-2 rounded-md transition-colors ${active ? 'bg-[#1e293b] text-blue-400' : 'hover:bg-white/5 text-muted-foreground'}`}
                      >
                        <item.icon className={`w-4 h-4 mr-2 ${active ? 'text-blue-400' : 'text-muted-foreground'}`} />
                        <span className="text-sm font-medium">{item.title}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="p-2">
            <Button 
              variant="ghost" 
              className="w-full justify-start text-[#4ade80] hover:text-[#4ade80] hover:bg-[#4ade80]/10 gap-2 h-10 px-3 bg-[#4ade80]/10 rounded-md border border-[#4ade80]/20"
            >
              <SiReactos className="w-4 h-4" />
              <span className="font-medium text-sm">System Tour</span>
            </Button>
          </SidebarFooter>
        </Sidebar>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Top Navbar */}
          <header className="h-14 border-b border-white/5 flex items-center justify-between px-6 bg-[#0b1121]">
            <div className="font-semibold text-lg text-white">Welcome Dev User</div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="Search everything..." 
                  className="bg-[#151b2b] border-white/5 h-9 w-[300px] pl-9 text-sm focus-visible:ring-blue-500/20 placeholder:text-muted-foreground/50"
                />
              </div>
              <Button size="icon" variant="ghost" className="h-9 w-9 text-muted-foreground hover:text-white">
                <Moon className="w-4 h-4" />
              </Button>
              <Button variant="outline" className="border-[#4ade80]/50 text-[#4ade80] hover:bg-[#4ade80]/10 h-8 gap-2 px-3 bg-transparent">
                <Eye className="w-4 h-4" />
                User View
              </Button>
              <Button size="icon" variant="ghost" className="h-9 w-9 text-muted-foreground hover:text-white">
                <Bell className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                className="text-muted-foreground hover:text-white h-9 gap-2 px-2"
                onClick={() => logoutMutation.mutate()}
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </Button>
            </div>
          </header>

          {/* Page Content */}
          <main className="flex-1 overflow-auto p-8">
            {renderContent()}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
