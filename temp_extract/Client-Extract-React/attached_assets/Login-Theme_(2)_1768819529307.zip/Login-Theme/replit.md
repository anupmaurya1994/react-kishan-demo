# MedCore - Patient Management System

## Overview

MedCore is a full-stack patient management application built with React and Express. It provides healthcare professionals with a dashboard to manage patient records, including features for authentication, patient CRUD operations, and a dark-themed modern UI.

The application follows a monorepo structure with a React frontend (Vite), Express backend, and PostgreSQL database using Drizzle ORM for type-safe database operations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite with HMR support

The frontend is organized in `client/src/` with:
- `pages/` - Route components (Login, Dashboard, Patients)
- `components/` - Reusable UI components including shadcn/ui
- `hooks/` - Custom hooks for auth, patients, and utilities
- `lib/` - Utility functions and API client setup

### Backend Architecture
- **Framework**: Express 5 with TypeScript
- **Authentication**: Passport.js with local strategy (username/password)
- **Session Management**: Express session with memory store
- **Password Security**: Scrypt hashing with timing-safe comparison
- **API Design**: RESTful endpoints defined in `shared/routes.ts`

The backend is in `server/` with:
- `index.ts` - Server entry point and middleware setup
- `routes.ts` - API route handlers
- `auth.ts` - Authentication configuration
- `storage.ts` - Database abstraction layer
- `db.ts` - Drizzle database connection

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` (shared between frontend and backend)
- **Migrations**: Drizzle Kit with `db:push` command
- **Validation**: Zod schemas generated from Drizzle schemas via `drizzle-zod`

### Shared Code
The `shared/` directory contains code used by both frontend and backend:
- `schema.ts` - Database table definitions and Zod validation schemas
- `routes.ts` - API route definitions with type-safe request/response schemas

### Build System
- Development: `tsx` for server, Vite dev server for client with proxy
- Production: ESBuild bundles server, Vite builds client to `dist/public`
- Dependencies are selectively bundled to optimize cold start times

## External Dependencies

### Database
- **PostgreSQL**: Primary database, configured via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries and schema management

### Authentication & Sessions
- **Passport.js**: Authentication middleware with local strategy
- **express-session**: Session management
- **memorystore**: In-memory session storage (for development; production should use `connect-pg-simple`)

### UI Component Libraries
- **Radix UI**: Headless UI primitives for accessibility
- **shadcn/ui**: Pre-styled component library using Radix + Tailwind
- **Lucide React**: Icon library
- **react-icons**: Additional icons (Facebook, etc.)

### Form & Validation
- **React Hook Form**: Form state management
- **Zod**: Schema validation for forms and API
- **@hookform/resolvers**: Zod integration for React Hook Form

### Date Handling
- **date-fns**: Date formatting and manipulation

### Development Tools
- **Vite**: Frontend build tool with HMR
- **tsx**: TypeScript execution for Node.js
- **ESBuild**: Production bundling for server
- **Drizzle Kit**: Database migration tool