import { 
  ArrowUpDown, 
  MoreHorizontal, 
  Search, 
  UserPlus,
  Mail,
  Plus,
  X,
  ChevronLeft,
  ChevronRight,
  Columns,
  CreditCard,
  UserCircle,
  Settings2,
  ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const usersData = [
  { username: "jeffrey_collins81", name: "Jeffrey Collins", email: "jeffrey.stark98@hotmail.com", phone: "+14646410541", status: "Inactive", role: "Manager" },
  { username: "ashton.auer", name: "Ashton Auer", email: "ashton_hegmann67@yahoo.com", phone: "+14345495030", status: "Suspended", role: "Superadmin" },
  { username: "golda.gleason", name: "Golda Gleason", email: "golda.smith32@gmail.com", phone: "+14606427316", status: "Active", role: "Manager" },
  { username: "maurine.rutherford", name: "Maurine Rutherford", email: "maurine_bechtelar@gmail.com", phone: "+16544865144", status: "Suspended", role: "Manager" },
  { username: "alford.wehner", name: "Alford Wehner", email: "alford36@hotmail.com", phone: "+12134843128", status: "Active", role: "Manager" },
  { username: "rahsaan.hagenes", name: "Rahsaan Hagenes", email: "rahsaan_russel@yahoo.com", phone: "+18972356925", status: "Suspended", role: "Superadmin" },
  { username: "madge_armstrong...", name: "Madge Armstrong", email: "madge.lubowitz62@yahoo.com", phone: "+15702447980", status: "Active", role: "Superadmin" },
  { username: "john.gottlieb-weber", name: "John Gottlieb-Weber", email: "john_oberbrunner15@gmail.com", phone: "+19516279869", status: "Inactive", role: "Superadmin" },
  { username: "marilyne.mohr63", name: "Marilyne Mohr", email: "marilyne.weimann@yahoo.com", phone: "+14238963008", status: "Inactive", role: "Superadmin" },
  { username: "cordelia_sanford", name: "Cordelia Sanford", email: "cordelia81@yahoo.com", phone: "+13865989429", status: "Invited", role: "Superadmin" },
];

export default function UserList() {
  return (
    <div className="space-y-6 bg-white min-h-full text-slate-900 font-sans p-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#0f172a]">User List</h1>
          <p className="text-slate-500 text-sm mt-1">Manage your users and their roles here.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="h-10 border-slate-200 hover:bg-slate-50 gap-2 text-slate-700 px-4">
            Invite User <Mail className="w-4 h-4" />
          </Button>
          <Button className="h-10 bg-[#0b1121] hover:bg-[#1e293b] text-white gap-2 px-4">
            Add User <UserPlus className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 flex-1">
          <div className="relative w-52">
            <Input 
              placeholder="Filter users..." 
              className="h-9 border-slate-200 focus-visible:ring-slate-200 bg-white placeholder:text-slate-400"
            />
          </div>
          <Button variant="outline" className="h-9 border-dashed border-slate-200 text-slate-700 gap-1 px-3">
            <Plus className="w-3.5 h-3.5" /> Status
          </Button>
          <Button variant="outline" className="h-9 border-dashed border-slate-200 text-slate-700 gap-1 px-3">
            <Plus className="w-3.5 h-3.5" /> Role
          </Button>
          
          <div className="flex items-center gap-2 ml-2">
            <Badge variant="secondary" className="bg-slate-100 text-slate-600 hover:bg-slate-200 px-2 py-1 rounded font-normal gap-1">
              Superadmin
            </Badge>
            <Badge variant="secondary" className="bg-slate-100 text-slate-600 hover:bg-slate-200 px-2 py-1 rounded font-normal gap-1">
              Manager
            </Badge>
          </div>
          
          <Button variant="ghost" className="h-9 text-slate-900 font-semibold text-sm hover:bg-slate-50 ml-2">
            Reset
          </Button>
          <Button variant="ghost" size="icon" className="h-9 w-9 text-slate-400">
            <X className="w-4 h-4" />
          </Button>
        </div>
        
        <Button variant="outline" className="h-9 border-slate-200 gap-2 text-slate-700">
          <Settings2 className="w-4 h-4" />
          View
        </Button>
      </div>

      {/* Table */}
      <div className="overflow-hidden border border-slate-200 rounded-lg">
        <Table>
          <TableHeader className="bg-slate-50/50 border-b border-slate-200">
            <TableRow className="hover:bg-transparent">
              <TableHead className="w-12 px-4"><Checkbox className="border-slate-300" /></TableHead>
              <TableHead className="text-slate-900 font-semibold text-sm px-4">Username <ArrowUpDown className="w-3 h-3 inline ml-1 opacity-40" /></TableHead>
              <TableHead className="text-slate-900 font-semibold text-sm px-4">Name</TableHead>
              <TableHead className="text-slate-900 font-semibold text-sm px-4">Email</TableHead>
              <TableHead className="text-slate-900 font-semibold text-sm px-4">Phone Number</TableHead>
              <TableHead className="text-slate-900 font-semibold text-sm px-4">Status</TableHead>
              <TableHead className="text-slate-900 font-semibold text-sm px-4">Role</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {usersData.map((user, i) => (
              <TableRow key={i} className="border-slate-200 hover:bg-slate-50/50 transition-colors h-[52px]">
                <TableCell className="px-4"><Checkbox className="border-slate-300" /></TableCell>
                <TableCell className="text-slate-900 font-medium text-sm px-4">{user.username}</TableCell>
                <TableCell className="text-slate-600 text-sm px-4">{user.name}</TableCell>
                <TableCell className="text-slate-600 text-sm px-4">{user.email}</TableCell>
                <TableCell className="text-slate-600 text-sm px-4">{user.phone}</TableCell>
                <TableCell className="px-4">
                  <Badge variant="outline" className={`
                    ${user.status === 'Active' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                      user.status === 'Invited' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                      user.status === 'Suspended' ? 'bg-red-50 text-red-600 border-red-100' :
                      'bg-slate-100 text-slate-600 border-slate-200'} 
                    font-medium px-2.5 py-0.5 rounded-full text-[11px]
                  `}>
                    {user.status}
                  </Badge>
                </TableCell>
                <TableCell className="px-4">
                  <div className="flex items-center gap-2 text-slate-600 text-sm">
                    {user.role === 'Superadmin' ? <ShieldCheck className="w-4 h-4 text-slate-400" /> : 
                     <UserCircle className="w-4 h-4 text-slate-400" />}
                    {user.role}
                  </div>
                </TableCell>
                <TableCell className="px-4 text-right">
                  <Button size="icon" variant="ghost" className="w-8 h-8 text-slate-400 hover:text-slate-900">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
