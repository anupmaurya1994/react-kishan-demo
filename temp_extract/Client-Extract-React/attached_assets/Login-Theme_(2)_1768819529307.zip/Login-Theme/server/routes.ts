import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { insertUserSchema, insertPatientSchema } from "@shared/schema";
import { setupAuth } from "./auth"; // Will setup after this file
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth setup
  setupAuth(app);

  // Patients API
  app.get(api.patients.list.path, async (_req, res) => {
    if (!(_req as any).isAuthenticated()) {
       return res.sendStatus(401);
    }
    const patients = await storage.getPatients();
    res.json(patients);
  });

  app.post(api.patients.create.path, async (req, res) => {
    if (!(req as any).isAuthenticated()) return res.sendStatus(401);
    try {
      const data = insertPatientSchema.parse(req.body);
      const patient = await storage.createPatient(data);
      res.status(201).json(patient);
    } catch (e: any) {
      if (e instanceof z.ZodError) {
        res.status(400).json(e.errors);
      } else {
        res.status(500).json({ message: e.message });
      }
    }
  });

  app.put(api.patients.update.path, async (req, res) => {
    if (!(req as any).isAuthenticated()) return res.sendStatus(401);
    const id = parseInt(req.params.id as string);
    try {
      const data = insertPatientSchema.partial().parse(req.body);
      const updated = await storage.updatePatient(id, data);
      if (!updated) return res.status(404).send("Patient not found");
      res.json(updated);
    } catch (e: any) {
      if (e instanceof z.ZodError) {
        res.status(400).json(e.errors);
      } else {
        res.status(500).json({ message: e.message });
      }
    }
  });

  app.delete(api.patients.delete.path, async (req, res) => {
    if (!(req as any).isAuthenticated()) return res.sendStatus(401);
    const id = parseInt(req.params.id as string);
    await storage.deletePatient(id);
    res.sendStatus(204);
  });
  
  // Seed data if empty
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const defaultUsername = "admin@yopmail.com";
  const defaultPassword = "anup1994##";
  const existingUser = await storage.getUserByUsername(defaultUsername);
  if (!existingUser) {
    await storage.createUser({ username: defaultUsername, password: defaultPassword });
    console.log("Seeded admin user");
  }

  const existingPatients = await storage.getPatients();
  if (existingPatients.length === 0) {
    await storage.createPatient({
      patientId: "PT-220804",
      name: "Joseph Miller",
      dateOfBirth: "1950-05-11",
      email: "joseph.miller904@email.com",
      phone: "(230) 780-5168",
      status: "Verified",
    });
    await storage.createPatient({
      patientId: "PT-480341",
      name: "Sarah Johnson",
      dateOfBirth: "1979-12-07",
      email: "sarah.j@email.com",
      phone: "(936) 819-2949",
      status: "Verified",
    });
    await storage.createPatient({
      patientId: "PT-373591",
      name: "Michael Chen",
      dateOfBirth: "1976-08-16",
      email: "m.chen@email.com",
      phone: "(508) 209-4724",
      status: "Verified",
    });
    await storage.createPatient({
      patientId: "PT-797715",
      name: "Emma Davis",
      dateOfBirth: "1996-08-25",
      email: "emma.d@email.com",
      phone: "(225) 327-2310",
      status: "Unverified",
    });
     console.log("Seeded patients");
  }
}
